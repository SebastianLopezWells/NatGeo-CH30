# NatGeo-CH30
This is a repository for 102 HTML &amp; CSS (intermediate) where we are going to replicate NatGeo web Page for the CH30
